<?php get_header();?>
	<h1>hola desde index.php</h1>



<?php get_footer(); ?>