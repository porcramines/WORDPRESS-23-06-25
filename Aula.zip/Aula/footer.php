  
	
	<h1>Hola desde footer.php</h1>
    <?php wp_footer(); ?>
</body>
</html>